sdb -d root on

#create repository for patch files

echo -e "\n\n---- Install GL DDK ----"
sdb -d shell mkdir -p /tmp/pkg/
sdb -d push gl-ddk/pkg/*.rpm /tmp/pkg/
sdb -d shell rpm -e --nodeps coregl
sdb -d shell rpm -e --nodeps libwayland-drm
sdb -d shell rpm -e --nodeps libwayland-egl
sdb -d shell rpm -e --nodeps libtpl-egl
sdb -d shell rpm -e --nodeps opengl-es-mali-midgard
sdb -d shell rpm -e --nodeps opengl-es-virtual-drv
sdb -d shell rpm -e --nodeps mesa-libglapi
sdb -d shell rpm -e --nodeps mesa
sdb -d shell rpm -e --nodeps mesa-libEGL
sdb -d shell rpm -e --nodeps mesa-libGLESv2
sdb -d shell rpm -Uvh --nodeps --force /tmp/pkg/*.rpm
sdb -d shell rm -rf /tmp/pkg
sdb -d push gl-ddk/conf/99-GPU-Acceleration.rules /etc/udev/rules.d/

echo -e "\n\n---- Install Zigbee Plugin ----"
sdb -d shell mkdir -p /tmp/pkg/
sdb -d push zigbee/pkg/*.rpm /tmp/pkg/
sdb -d shell rpm -Uvh --nodeps --force /tmp/pkg/*.rpm
sdb -d shell rm -rf /tmp/pkg

######################################################################
echo -e "\n\n---- Temporary patch ----"
sdb -d shell mkdir -p /tmp/patchtmp

sdb -d push target/*.cfg /tmp/patchtmp

sdb -d shell cp -f /tmp/patchtmp/e_comp_artik.cfg /usr/share/enlightenment/data/config/tizen-common/e_comp.cfg
sdb -d shell rm -rf /var/lib/enlightenment/.e

sdb -d shell rm -rf /tmp/patchtmp
######################################################################

echo -e "\n\n----- Sync & Reboot -----\n"
sdb -d shell sync
sdb -d shell reboot -f
