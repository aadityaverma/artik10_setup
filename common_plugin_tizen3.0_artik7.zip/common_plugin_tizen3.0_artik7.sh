#echo -e "\n\n----- sdb enable -----\n"
#./scripts/connect.sh /dev/ttyUSB0 115200

#sleep 5

sdb -d root on

echo -e "\n\n----- Replace files for ARTIK710 -----\n"
#sdb push etc/fstab /etc/
sdb push etc/boot-animation.service /usr/lib/systemd/system/
sdb push etc/hifi /usr/share/alsa/ucm/ak4953/

#create repository for patch files
sdb -d shell mkdir -p /tmp/patchtmp

echo -e "\n\n---- Instal packages for ARTIK710 -----\n"
sdb -d push etc/libdrm-*.rpm /tmp/patchtmp
sdb -d push etc/libtbm-nexell-*.rpm /tmp/patchtmp
sdb -d shell rpm -Uvh --force /tmp/patchtmp/libdrm-*.rpm
sdb -d shell rpm -Uvh --force /tmp/patchtmp/libtbm-nexell-*.rpm

sdb -d shell rm -rf /tmp/patchtmp

echo -e "\n\n---- Install GL DDK ----"
sdb -d shell mkdir -p /tmp/pkg/
sdb -d push gl-ddk/pkg/*.rpm /tmp/pkg/
sdb -d shell rpm -e --nodeps coregl
sdb -d shell rpm -e --nodeps libwayland-drm
sdb -d shell rpm -e --nodeps libwayland-egl
sdb -d shell rpm -e --nodeps libtpl-egl
sdb -d shell rpm -e --nodeps opengl-es-mali-utgard
sdb -d shell rpm -e --nodeps opengl-es-virtual-drv
sdb -d shell rpm -e --nodeps mesa-libglapi
sdb -d shell rpm -e --nodeps mesa
sdb -d shell rpm -e --nodeps mesa-libEGL
sdb -d shell rpm -e --nodeps mesa-libGLESv2
sdb -d shell rpm -Uvh --nodeps --force /tmp/pkg/*.rpm
sdb -d shell rm -rf /tmp/pkg
sdb -d push gl-ddk/conf/99-GPU-Acceleration.rules /etc/udev/rules.d/

echo -e "\n\n---- Install Zigbee Plugin ----"
sdb -d shell mkdir -p /tmp/pkg/
sdb -d push zigbee/pkg/*.rpm /tmp/pkg/
sdb -d shell rpm -Uvh --nodeps --force /tmp/pkg/*.rpm
sdb -d shell rm -rf /tmp/pkg

######################################################################
echo -e "\n\n---- Temporary patch ----"
sdb -d shell mkdir -p /tmp/patchtmp

sdb -d push target/*.cfg /tmp/patchtmp

sdb -d shell cp -f /tmp/patchtmp/e_comp_artik.cfg /usr/share/enlightenment/data/config/tizen-common/e_comp.cfg
sdb -d shell rm -rf /var/lib/enlightenment/.e

sdb -d shell rm -rf /tmp/patchtmp
######################################################################

echo -e "\n\n----- Sync & Reboot -----\n"
sdb -d shell sync
sdb -d shell reboot -f
